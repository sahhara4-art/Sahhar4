# Proguard rules for Humanitarian Aid Management
-keep class com.humanitarian.aidmanagement.data.local.entities.** { *; }
-keep class com.humanitarian.aidmanagement.data.local.dao.** { *; }
