package com.humanitarian.aidmanagement.notifications

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object NotificationScheduler {

    private const val PERIODIC_WORK_TAG = "aid_periodic_notification_worker"

    /**
     * جدولة فحص دوري يومي لقاعدة البيانات للتذكير بالتوزيعات وانتهاء الاستثناء
     */
    fun schedulePeriodicCheck(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val periodicWorkRequest = PeriodicWorkRequestBuilder<AidNotificationWorker>(
            12, TimeUnit.HOURS, // فحص كل 12 ساعة
            1, TimeUnit.HOURS    // مرونة 1 ساعة
        )
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_WORK_TAG,
            ExistingPeriodicWorkPolicy.KEEP,
            periodicWorkRequest
        )
    }

    /**
     * تشغيل فحص فوري لمرة واحدة (OneTimeWorkRequest) عند تشغيل التطبيق أو النقر على تحديث
     */
    fun triggerImmediateCheck(context: Context) {
        val oneTimeWorkRequest = OneTimeWorkRequestBuilder<AidNotificationWorker>()
            .build()

        WorkManager.getInstance(context).enqueue(oneTimeWorkRequest)
    }
}
