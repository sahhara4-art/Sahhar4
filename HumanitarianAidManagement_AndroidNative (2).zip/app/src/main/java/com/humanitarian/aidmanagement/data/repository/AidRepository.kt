package com.humanitarian.aidmanagement.data.repository

import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.*
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.engine.NominationCandidate
import com.humanitarian.aidmanagement.engine.NominationEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class AidRepository(
    private val database: AidDatabase,
    private val nominationEngine: NominationEngine
) {
    // المستخدم الحالي المسجل
    private var currentUser: UserEntity? = null
    private var currentUserLocalityIds: List<Int> = emptyList()

    fun setCurrentUser(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
    }

    fun getCurrentUser(): UserEntity? = currentUser
    fun getCurrentUserLocalityIds(): List<Int> = currentUserLocalityIds

    // صلاحيات المستخدم
    fun canManageAllLocalities(): Boolean {
        return currentUserLocalityIds.contains(0) || currentUser?.RoleID == 1
    }

    fun canAccessLocality(localityId: Int): Boolean {
        if (canManageAllLocalities()) return true
        return currentUserLocalityIds.contains(localityId)
    }

    // الأسر
    fun getFamilies(query: String = "", localityId: Int? = null, shelterStatus: String? = null): Flow<List<FamilyEntity>> {
        val effectiveLocalityId = if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        return database.familyDao().searchFamilies(query, effectiveLocalityId, shelterStatus)
    }

    suspend fun insertFamily(family: FamilyEntity): Long {
        return database.familyDao().insertFamily(family)
    }

    suspend fun updateFamily(family: FamilyEntity) {
        database.familyDao().updateFamily(family)
    }

    suspend fun deleteFamily(family: FamilyEntity) {
        database.familyDao().deleteFamily(family)
    }

    // الأطفال
    fun getChildrenByFamily(familyNationalId: String): Flow<List<ChildEntity>> {
        return database.childDao().getChildrenByFamilyNationalId(familyNationalId)
    }

    fun searchChildren(query: String): Flow<List<ChildEntity>> {
        return database.childDao().searchChildren(query)
    }

    suspend fun insertChild(child: ChildEntity): Long {
        return database.childDao().insertChild(child)
    }

    suspend fun deleteChild(child: ChildEntity) {
        database.childDao().deleteChild(child)
    }

    // أنواع المساعدات والمشاريع
    fun getActiveAidTypes(): Flow<List<AidTypeEntity>> = database.aidTypeDao().getAllActiveAidTypes()
    fun getActiveProjects(): Flow<List<ProjectEntity>> = database.projectDao().getAllActiveProjects()
    fun getLocalities(): Flow<List<LocalityEntity>> = database.localityDao().getAllLocalities()
    fun getDistributions(): Flow<List<LocalityDistributionEntity>> = database.localityDao().getDistributions()

    suspend fun insertProject(project: ProjectEntity): Long = database.projectDao().insertProject(project)

    // إحصائيات لوحة التحكم
    suspend fun getDashboardStats(): DashboardStats {
        val totalFamilies = database.familyDao().getTotalFamiliesCount()
        val totalBeneficiaries = database.familyDao().getTotalBeneficiariesCount() ?: 0
        val totalAidRecords = database.aidRecordDao().getTotalAidRecordsCount()
        val totalProjects = database.projectDao().getTotalProjectsCount()
        val totalSelected = database.nominationDao().getTotalSelectedCount()
        val distinctBeneficiaries = database.aidRecordDao().getDistinctBeneficiariesCount()

        return DashboardStats(
            totalFamilies = totalFamilies,
            totalBeneficiaries = totalBeneficiaries,
            totalAidRecords = totalAidRecords,
            totalProjects = totalProjects,
            totalSelectedCandidates = totalSelected,
            distinctBeneficiaries = distinctBeneficiaries
        )
    }

    // الترشيح اليدوي
    suspend fun getEligibleFamiliesForManual(localityId: Int?): List<FamilyEntity> {
        val families = database.familyDao().getEligibleFamiliesForNomination(localityId)
        return if (canManageAllLocalities()) {
            families
        } else {
            families.filter { currentUserLocalityIds.contains(it.localityID) }
        }
    }

    suspend fun addManualSelection(familyId: Long, aidTypeId: Int, projectId: Long, userId: Int) {
        val selection = ManualSelectionEntity(
            CitizenID = familyId,
            SelectionDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
            UserID = userId,
            AidTypeID = aidTypeId,
            ProjectID = projectId
        )
        database.nominationDao().insertManualSelection(selection)
    }

    suspend fun removeManualSelection(familyId: Long, aidTypeId: Int, projectId: Long) {
        database.nominationDao().removeManualSelection(familyId, aidTypeId, projectId)
    }

    suspend fun clearManualSelections(aidTypeId: Int, projectId: Long) {
        database.nominationDao().clearManualSelections(aidTypeId, projectId)
    }

    // تنفيذ الترشيح المشترك
    suspend fun runNomination(
        localityId: Int?,
        aidTypeIds: List<Int>,
        projectId: Long,
        requiredCount: Int,
        customExclusionDays: Int = 30
    ): List<NominationCandidate> {
        val userId = currentUser?.UserID ?: 1
        return nominationEngine.executeFullNomination(
            localityId = localityId,
            aidTypeIds = aidTypeIds,
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = currentUserLocalityIds,
            customExclusionDays = customExclusionDays
        )
    }

    // توافق مع الاستدعاء بتصنيف فردي
    suspend fun runNomination(
        localityId: Int?,
        aidTypeId: Int,
        projectId: Long,
        requiredCount: Int
    ): List<NominationCandidate> {
        return runNomination(
            localityId = localityId,
            aidTypeIds = listOf(aidTypeId),
            projectId = projectId,
            requiredCount = requiredCount,
            customExclusionDays = 30
        )
    }

    // توزيع الحصص
    suspend fun calculateQuotas(totalRequired: Int): List<LocalityQuota> {
        val distributions = database.localityDao().getDistributions().first()
        val localities = database.localityDao().getAllLocalities().first().associate { it.LocalityID to it.LocalityName }
        return nominationEngine.calculateLocalityQuotas(totalRequired, distributions, localities)
    }

    // استيراد معايير الترشيح والترحيل
    suspend fun runNominationWithCriteria(
        localityId: Int?,
        criteria: com.humanitarian.aidmanagement.engine.NominationCriteria,
        projectId: Long,
        requiredCount: Int
    ): List<NominationCandidate> {
        val userId = currentUser?.UserID ?: 1
        return nominationEngine.executeCriteriaNomination(
            localityId = localityId,
            criteria = criteria,
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = currentUserLocalityIds
        )
    }

    // ترحيل واعتماد المرشحين رسمياً وتسجيل بيانات المشروع المنفذ
    suspend fun dispatchNominatedAid(
        candidates: List<NominationCandidate>,
        dispatchInfo: com.humanitarian.aidmanagement.engine.ProjectDispatchInfo
    ) {
        val userId = currentUser?.UserID ?: 1
        val selectedEntities = candidates.map {
            SelectedCitizenEntity(
                CitizenID = it.family.familyID,
                SelectionDate = dispatchInfo.nominationDate,
                SelectionType = it.selectionType,
                AidTypeID = dispatchInfo.targetAidTypeId,
                ProjectID = dispatchInfo.projectNumber.filter { c -> c.isDigit() }.toLongOrNull() ?: 1L,
                UserID = userId
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        val parsedVal = dispatchInfo.aidValue.filter { c -> c.isDigit() || c == '.' }.toDoubleOrNull() ?: 50.0
        candidates.forEach { candidate ->
            val aidRecord = AidRecordEntity(
                familyID = candidate.family.familyID,
                aidTypeID = dispatchInfo.targetAidTypeId,
                projectID = dispatchInfo.projectNumber.filter { c -> c.isDigit() }.toLongOrNull() ?: 1L,
                aidDate = dispatchInfo.nominationDate,
                selectionDate = dispatchInfo.nominationDate,
                deliveryDate = dispatchInfo.nominationDate,
                recipientStatus = "معتمد للترحيل والتسليم",
                warehouse = dispatchInfo.warehouseName,
                aidValue = parsedVal,
                notes = "المشروع: ${dispatchInfo.projectNumber} - الممول: ${dispatchInfo.fundingOrganization} - نوع المساعدة: ${dispatchInfo.aidTypeName}"
            )
            database.aidRecordDao().insertAidRecord(aidRecord)
        }
    }

    // اعتماد وحفظ نتائج الترشيح في tbl_Selected_Citizens وسجلات المساعدات
    suspend fun confirmAndCommitNomination(
        candidates: List<NominationCandidate>,
        aidTypeId: Int,
        projectId: Long
    ) {
        val userId = currentUser?.UserID ?: 1
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())

        val selectedEntities = candidates.map {
            SelectedCitizenEntity(
                CitizenID = it.family.familyID,
                SelectionDate = today,
                SelectionType = it.selectionType,
                AidTypeID = aidTypeId,
                ProjectID = projectId,
                UserID = userId
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        // إدراج سجلات المساعدة الأولية بحالة "مرشح"
        candidates.forEach { candidate ->
            val aidRecord = AidRecordEntity(
                familyID = candidate.family.familyID,
                aidTypeID = aidTypeId,
                projectID = projectId,
                aidDate = today,
                selectionDate = today,
                recipientStatus = "مرشح",
                warehouse = "المستودع المركزي",
                aidValue = 50.0
            )
            database.aidRecordDao().insertAidRecord(aidRecord)
        }

        // مسح الترشيحات اليدوية المؤقتة بعد الاعتماد
        database.nominationDao().clearManualSelections(aidTypeId, projectId)
    }
}

data class DashboardStats(
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalAidRecords: Int,
    val totalProjects: Int,
    val totalSelectedCandidates: Int,
    val distinctBeneficiaries: Int
)
