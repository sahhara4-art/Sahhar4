package com.humanitarian.aidmanagement.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AidNotificationWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val database = AidDatabase.getDatabase(context, kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob()))
            val aidRecordDao = database.aidRecordDao()
            val familyDao = database.familyDao()
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val today = Date()

            // 1. فحص تواريخ المشاريع والتوزيعات القادمة (خلال الـ 48 ساعة القادمة)
            // في البيئة التشغيلية: استعلام جدول المشاريع projects وتحديد المواعيد القريبة
            val cal48h = Calendar.getInstance().apply {
                time = today
                add(Calendar.DAY_OF_YEAR, 2)
            }
            val upcomingDateStr = dateFormat.format(cal48h.time)

            // إشعار تذكيري بمشروع التوزيع القادم
            AidNotificationHelper.notifyUpcomingDistribution(
                context = context,
                notificationId = 1001,
                projectNumber = "PRJ-2026-DIST-01",
                projectName = "مشروع توزيع الطرود الغذائية الطارئة",
                aidTypeName = "طرد غذائي عائلي",
                distributionDate = upcomingDateStr,
                warehouseName = "مستودع الشيخ رضوان المركزي",
                beneficiariesCount = 150
            )

            // 2. فحص المستفيدين الذين أوشكت فترة استثنائهم على الانتهاء من قاعدة البيانات
            // معيار الافتراض: استثناء 30 يوماً من تاريخ آخر مساعدة
            val allFamilies = familyDao.getAllFamiliesSync()
            var alertCount = 0

            for (family in allFamilies) {
                if (alertCount >= 3) break // بحد أقصى 3 إشعارات تفادياً للإزعاج

                val lastRecord = aidRecordDao.getLastAidForFamily(family.familyID)
                if (lastRecord != null && !lastRecord.aidDate.isNullOrEmpty()) {
                    try {
                        val aidDate = dateFormat.parse(lastRecord.aidDate)
                        if (aidDate != null) {
                            // فترة الاستثناء الافتراضية 30 يوماً
                            val expiryCal = Calendar.getInstance().apply {
                                time = aidDate
                                add(Calendar.DAY_OF_YEAR, 30)
                            }
                            val expiryDate = expiryCal.time
                            val diffMillis = expiryDate.time - today.time
                            val remainingDays = (diffMillis / (1000 * 60 * 60 * 24)).toInt()

                            // إذا كانت الأيام المتبقية بين 0 و 5 أيام: إرسال تنبيه محلي
                            if (remainingDays in 0..5) {
                                AidNotificationHelper.notifyExclusionExpiring(
                                    context = context,
                                    notificationId = 2000 + family.familyID.toInt(),
                                    familyName = family.name,
                                    nationalId = family.nationalID,
                                    aidTypeName = "طرد غذائي / مساعدات عينية",
                                    remainingDays = remainingDays,
                                    expirationDate = dateFormat.format(expiryDate)
                                )
                                alertCount++
                            }
                        }
                    } catch (_: Exception) {
                        // Skip unparseable dates
                    }
                }
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }
}
