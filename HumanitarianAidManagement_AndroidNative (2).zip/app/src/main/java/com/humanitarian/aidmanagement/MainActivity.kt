package com.humanitarian.aidmanagement

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.humanitarian.aidmanagement.ui.navigation.Screen
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import com.humanitarian.aidmanagement.ui.screens.dashboard.DashboardScreen
import com.humanitarian.aidmanagement.ui.screens.families.FamiliesScreen
import com.humanitarian.aidmanagement.ui.screens.login.LoginScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.ManualSelectionScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationResultsScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationScreen
import com.humanitarian.aidmanagement.ui.screens.reports.ReportsScreen
import com.humanitarian.aidmanagement.ui.screens.backup.BackupRestoreScreen
import com.humanitarian.aidmanagement.ui.theme.HumanitarianAidTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as AidApplication
        val repository = app.repository
        val database = app.database

        setContent {
            HumanitarianAidTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val isLogin = currentRoute == Screen.Login.route

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (!isLogin && currentRoute != null && !currentRoute.startsWith("manual_selection")) {
                            NavigationBar {
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Dashboard.route,
                                    onClick = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "لوحة التحكم") },
                                    label = { Text("الرئيسية") }
                                )
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Families.route,
                                    onClick = {
                                        navController.navigate(Screen.Families.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.FamilyRestroom, contentDescription = "الأسر") },
                                    label = { Text("الأسر") }
                                )
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Nomination.route,
                                    onClick = {
                                        navController.navigate(Screen.Nomination.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.HowToReg, contentDescription = "الترشيح") },
                                    label = { Text("الترشيح") }
                                )
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Children.route,
                                    onClick = {
                                        navController.navigate(Screen.Children.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.ChildCare, contentDescription = "الأطفال") },
                                    label = { Text("الأطفال") }
                                )
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Reports.route,
                                    onClick = {
                                        navController.navigate(Screen.Reports.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.BarChart, contentDescription = "التقارير") },
                                    label = { Text("التقارير") }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Login.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Login.route) {
                            LoginScreen(
                                database = database,
                                repository = repository,
                                onLoginSuccess = {
                                    navController.navigate(Screen.Dashboard.route) {
                                        popUpTo(Screen.Login.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(Screen.Dashboard.route) {
                            DashboardScreen(
                                repository = repository,
                                onNavigateToFamilies = { navController.navigate(Screen.Families.route) },
                                onNavigateToNomination = { navController.navigate(Screen.Nomination.route) },
                                onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                                onNavigateToBackup = { navController.navigate(Screen.BackupRestore.route) }
                            )
                        }

                        composable(Screen.Families.route) {
                            FamiliesScreen(
                                repository = repository,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(Screen.Children.route) {
                            ChildrenScreen(
                                repository = repository,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(Screen.Nomination.route) {
                            NominationScreen(
                                repository = repository,
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToManualSelection = { aidId, prjId ->
                                    navController.navigate("manual_selection/$aidId/$prjId")
                                },
                                onNavigateToResults = {
                                    navController.navigate(Screen.NominationResults.route)
                                }
                            )
                        }

                        composable("manual_selection/{aidTypeId}/{projectId}") { backStackEntry ->
                            val aidTypeId = backStackEntry.arguments?.getString("aidTypeId")?.toIntOrNull() ?: 1
                            val projectId = backStackEntry.arguments?.getString("projectId")?.toLongOrNull() ?: 1L
                            ManualSelectionScreen(
                                repository = repository,
                                aidTypeId = aidTypeId,
                                projectId = projectId,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(Screen.NominationResults.route) {
                            NominationResultsScreen(
                                repository = repository,
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateHome = {
                                    navController.navigate(Screen.Dashboard.route) {
                                        popUpTo(Screen.Dashboard.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(Screen.Reports.route) {
                            ReportsScreen(
                                repository = repository,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(Screen.BackupRestore.route) {
                            BackupRestoreScreen(
                                database = database,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
