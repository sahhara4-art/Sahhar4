package com.humanitarian.aidmanagement.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val DarkColorScheme = darkColorScheme(
    primary = Emerald500,
    onPrimary = Slate950,
    primaryContainer = Emerald800,
    onPrimaryContainer = Emerald500,
    secondary = Sky500,
    background = Slate950,
    surface = Slate900,
    surfaceVariant = Slate800,
    onBackground = Slate100,
    onSurface = Slate100,
    error = Rose500
)

private val LightColorScheme = lightColorScheme(
    primary = Emerald600,
    onPrimary = Slate100,
    primaryContainer = Emerald700,
    secondary = Sky500,
    background = Slate100,
    surface = Slate100,
    surfaceVariant = Slate300,
    error = Rose500
)

@Composable
fun HumanitarianAidTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    // فرض اتجاه RTL للغة العربية دائماً
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
